import cli
interfaz = cli.cli()
interfaz.ejecutar()